MY TEACHING HUB V2

1. Open index.html in Chrome or Edge.
2. Add lesson files in Lesson Library. Files are stored in this browser via IndexedDB; they do not sync to other computers.
3. PPTX animations are preserved in the original file, which you can download and open in PowerPoint. PDF, video, audio and images have in-browser previews.
4. Sticky notes are teacher-entered; no student live participation or QR-code backend is included.
5. Scores and notes are stored in localStorage. Clearing site data removes them.
6. Do not put student-sensitive data in this prototype.
